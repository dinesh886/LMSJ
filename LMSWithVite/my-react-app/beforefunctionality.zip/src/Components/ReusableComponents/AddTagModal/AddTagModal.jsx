"use client"

import React, { useState, useEffect, useRef } from "react"
import './AddTagModal.css'
import { FaPlus } from "react-icons/fa"
import useBounceModal from "../../ReusableComponents/useBounceModal/useBounceModal"

const AddTagModal = ({
    isOpen,
    onClose,
    onAddTag,
    onEditTag,
    heading = "Create New Tag",
    existingTag = null,
    selectedSection = ""
}) => {
    const { modalRef, isBouncing } = useBounceModal(isOpen)
    const [tagName, setTagName] = useState("")
    const [selectedColor, setSelectedColor] = useState("#F04343")
    const [customColor, setCustomColor] = useState("#000000")
    const [error, setError] = useState("")
    const inputRef = useRef(null)

    const colorOptions = [
        "#F04343", "#DD8A3E", "#43A7F0",
        "#33CF67", "#FF4BCD", "#B943F0"
    ]

    // Initialize form when modal opens or existingTag changes
    useEffect(() => {
        if (existingTag) {
            setTagName(existingTag.name)
            setSelectedColor(existingTag.color)
            setCustomColor(existingTag.color)
        } else {
            setTagName(selectedSection || "")
            setSelectedColor(colorOptions[0])
            setCustomColor("#000000")
        }
    }, [isOpen, existingTag, selectedSection])

    // Auto-focus input when modal opens
    useEffect(() => {
        if (isOpen && inputRef.current) {
            inputRef.current.focus()
        }
    }, [isOpen])

    const handleSubmit = () => {
        if (!tagName.trim()) {
            setError("Tag name is required")
            return
        }

        const tagData = {
            name: tagName.trim(),
            color: selectedColor,
            questions: existingTag?.questions || []
        }

        if (existingTag) {
            onEditTag({ ...tagData, id: existingTag.id })
        } else {
            onAddTag({ ...tagData, id: Date.now() })
        }

        onClose()
    }

    const handleCustomColorChange = (e) => {
        const color = e.target.value
        setCustomColor(color)
        setSelectedColor(color)
    }

    const openColorPicker = () => {
        colorPickerRef.current?.click()
    }

    if (!isOpen) return null

    return (
        <div className="newtag-modal-overlay">
            <div className={`newtag-modal-content ${isBouncing ? "bounce" : ""}`} ref={modalRef}>
                <div className="newtag-modal-header">
                    <h5>{heading}</h5>
                    <button className="close-btn" onClick={onClose}>
                        &times;
                    </button>
                </div>

                <div className="newtag-modal-body">
                    <div className="newtag-form-group">
                        <input
                            type="text"
                            value={tagName}
                            onChange={(e) => {
                                setTagName(e.target.value)
                                setError("")
                            }}
                            placeholder="Enter Tag name"
                            className="newtag-form-control"
                            ref={inputRef}
                        />
                        {error && <p className="error-message">{error}</p>}
                    </div>

                    <div className="newtag-form-group">
                        <label>Choose Color</label>
                        <div className="color-options">
                            {colorOptions.map((color, index) => (
                                <div
                                    key={index}
                                    className={`color-option ${selectedColor === color ? "selected" : ""}`}
                                    style={{ backgroundColor: color }}
                                    onClick={() => {
                                        setSelectedColor(color)
                                        setCustomColor(color)
                                    }}
                                >
                                    {selectedColor === color && <span className="tick-icon">✔</span>}
                                </div>
                            ))}

                            <div
                                className={`color-option custom-color ${selectedColor === customColor ? "selected" : ""}`}
                                style={{ backgroundColor: customColor }}
                                onClick={openColorPicker}
                            >
                                {selectedColor === customColor ? (
                                    <span className="tick-icon">✔</span>
                                ) : (
                                    <span className="custom-color-label"><FaPlus /></span>
                                )}
                                <input
                                    type="color"
                                    ref={colorPickerRef}
                                    value={customColor}
                                    onChange={handleCustomColorChange}
                                    className="color-picker"
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="newtag-modal-footer">
                    <button className="btn cancel-btn" onClick={onClose}>
                        Cancel
                    </button>
                    <button
                        className={`btn create-btn ${tagName.trim() ? "" : "disabled"}`}
                        onClick={handleSubmit}
                        disabled={!tagName.trim()}
                    >
                        {existingTag ? "Update Tag" : "Create Tag"}
                    </button>
                </div>
            </div>
        </div>
    )
}

export default AddTagModal