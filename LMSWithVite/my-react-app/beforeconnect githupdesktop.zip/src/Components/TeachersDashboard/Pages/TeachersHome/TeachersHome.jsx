import React from "react";

const TeachersHome = () => {
    return <h2>Welcome to the Teachers Dashboard Home </h2>;
};

export default TeachersHome;
