import React from 'react'

const All = () => {
  return (
    <div
      className="container py-5"
      style={{ marginLeft: "250px", width: "calc(100% - 250px)" }}
    >
      <h1>all Question Banks</h1>
    </div>
  );
}

export default All
